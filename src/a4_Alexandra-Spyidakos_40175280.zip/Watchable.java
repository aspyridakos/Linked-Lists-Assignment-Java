//--------------------------------------------------------
//Part: 2
//Written by:Alexandra Spyridakos, 40175280
//--------------------------------------------------------

/**
 * Interface for TVShow class to check if a show can be viewed or not *
 */
public interface Watchable{
	String isOnSameTime(TVShow s);	
}